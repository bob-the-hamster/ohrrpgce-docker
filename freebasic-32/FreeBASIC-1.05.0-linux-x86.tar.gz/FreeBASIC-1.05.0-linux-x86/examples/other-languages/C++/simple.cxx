//
// compile with G++ 3.x or above:
//    g++ -c simple.cxx
//    ar rcs libsimple.a simple.o
//

namespace cpp 
{
	int sum( int a, int b ) 
	{ 
		return a + b;
	}
}
